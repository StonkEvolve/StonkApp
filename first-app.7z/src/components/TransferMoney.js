import { useState } from "react";
import { useHistory, useParams } from "react-router-dom";

import useFetch from "../data/useFetch";

const TransferMoney = () => {
    const { id } = useParams();
    const history = useHistory();

    const { data: client, error, isPending } = useFetch('/clients/' + id);
    //const { data: client, error, isPending } = useFetch('http://localhost:8000/clients/' + id);
    const [sumTo, setSumTo]       = useState(0);
    const [sumFrom, setSumFrom]   = useState(0);


    const handleSubmit = (e) => {
        e.preventDefault();
        
        let moneyTo = parseInt(sumTo);
        let moneyFrom = parseInt(sumFrom);

        let moneyTransfer = 0;
        if (!isNaN(moneyTo)) {moneyTransfer += moneyTo}
        if (!isNaN(moneyFrom)) {moneyTransfer -= moneyFrom}

        if (moneyTransfer !==0){
            console.log("client.id=", client.id )
            console.log("moneyTransfer=", moneyTransfer )
            fetch('/clients/'+client.id, {
                method: 'PATCH',
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({balance:moneyTransfer})
              }).then(() => {
                // history.go(-1);
                history.push('/clients');
              }).catch(err => {
                  console.log('fetch aborted'+err.message);
                  
                }
              )
        }
      }
   
    return (

        <div className="create">
            { isPending && <div>Loading...</div>}
            { error && <div>{error}</div>}
            { client && <div className="transfer-money">
                <h2>{client.firstName}</h2>
                <h2> {client.lastName}</h2>
                <h1>Transfer Money</h1>
                <form onSubmit={handleSubmit}>
                    <label>To Account:</label>
                    <input
                        type="text"
                        required
                        value={sumTo}
                        onChange={(e) => setSumTo(e.target.value)}
                    />
                    <label>From Account:</label>
                    <input
                        type="text"
                        required
                        value={sumFrom}
                        onChange={(e) => setSumFrom(e.target.value)}
                    />
                    <button >Transfer</button>
                </form>
            </div>}
        </div>
    );


}

export default TransferMoney

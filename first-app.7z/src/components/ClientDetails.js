import { useHistory, useParams } from "react-router-dom";
import useFetch from "../data/useFetch";

const ClientDetails = () => {
  const { id } = useParams();
//  const { data: client, error, isPending } = useFetch('http://localhost:8000/clients/' + id);
  const { data: client, error, isPending } = useFetch('/clients/' + id);
  const history = useHistory();

  const handleClick = () => {
    fetch('/clients/' + client.id, {
      method: 'DELETE'
    }).then(() => {
      history.push('/clients');
    }) 
  }

  return (
    <div className="client-details">
      { isPending && <div>Loading...</div> }
      { error && <div>{ error }</div> }
      { client && (
        <article>
          <h2>{ client.firstName }</h2>
          <p> { client.lastName }</p>
          <p> { client.phoneNumber}</p>
          <p> { client.eMail }</p>
          {/* <div>{ blog.body }</div> */}
          <button onClick={handleClick}>delete</button>
        </article>
      )}
    </div>
  );
}
 
export default ClientDetails;
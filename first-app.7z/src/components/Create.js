import { useState }   from "react";
import { useHistory } from "react-router-dom";

const Create = () => {
  const [firstName,   setFirstName]   = useState('');
  const [lastName,    setLastName]    = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [eMail, setEMail]             = useState('');
  
  const history = useHistory();

  const handleSubmit = (e) => {
    e.preventDefault();
    const client = { firstName, lastName, phoneNumber, eMail, balance:0 };

    fetch('/clients', {
      method: 'POST',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(client)
    }).then(() => {
      // history.go(-1);
      history.push('/clients');
    })
  }

  return (
    <div className="create">
      <h2>Add a New Client</h2>
      <form onSubmit={handleSubmit}>
        <label>First Name:</label>
        <input 
          type="text" 
          required 
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
        />
        <label>Last Name:</label>
        <input 
          type="text" 
          required 
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
        />
        <label>Phone Number:</label>
        <input 
          type="text" 
          required 
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
        />
        <label>eMail:</label>
        <input 
          type="text" 
          required 
          value={eMail}
          onChange={(e) => setEMail(e.target.value)}
        />

        <button>Add Client</button>
      </form>
    </div>
  );
}
 
export default Create;
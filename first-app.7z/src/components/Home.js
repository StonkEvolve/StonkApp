import ClientList from "./ClientList";
import useFetch from "../data/useFetch";

const Home = () => {
  const { error, isPending, data: clients } = useFetch('/clients')
  // const { error, isPending, data: clients } = useFetch('http://localhost:8000/clients')

  return (
    <div className="home">
      { error && <div>{ error }</div> }
      { isPending && <div>Loading...</div> }
      { clients && <ClientList clients={clients} /> }
    </div>
  );
}
 
export default Home;

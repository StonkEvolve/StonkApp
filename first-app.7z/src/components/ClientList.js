import { Link } from 'react-router-dom';

const ClientList = ({ clients }) => {
  return (
    <div className="client-list">
      {clients.map(client => (
        <div className="client-preview" key={client.id} >
          <Link to={`/clients/${client.id}`}>
            <h2>{ client.firstName }</h2>
            <h2>{ client.lastName }</h2>
            <h2>{ `${client.balance}CAD` }</h2>
          </Link>
          <Link to={`/clients/transferMoney/${client.id}`}>
            <h2>Transfer money</h2>
          </Link>
        </div>
      ))}
    </div>
  );
}
 
export default ClientList;
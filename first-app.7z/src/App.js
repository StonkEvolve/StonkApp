import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import Navbar         from './components/Navbar';
import Home           from './components/Home';
import Create         from './components/Create';
import ClientDetails  from './components/ClientDetails';
import TransferMoney  from './components/TransferMoney';
import NotFound       from './components/NotFound';

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <div className="content">
          <Switch>
            <Route exact path="/">
              <h1>Hello Storks !</h1>
            </Route>
            <Route path="/clients/create">
              <Create />
            </Route>
            <Route path="/clients/transferMoney/:id">
              <TransferMoney />
            </Route>
            <Route path="/clients/:id">
              <ClientDetails />
            </Route>
            <Route  path="/clients">
              <Home />
            </Route>
            
            
            <Route path="*">
              <NotFound />
            </Route>
          </Switch>
        </div>
      </div>
    </Router>
  );
}

export default App;

const fetch = require('node-fetch');

const stocksDB  = require("./stocksDB")
const alphaKey  = require("./alphaKey")

async function getCompanyInformation(symbol) {
    let company = await stocksDB.tryToFindCompanyInformation(symbol);
    if (company !== null) { return  company;}

    //console.log("load from alpha");
    company = await getCompanyInformationAlpha(symbol);
    if (Object.keys(company).length > 0 ){
        await stocksDB.saveCompanyInformation(company);
    }
    return company;
}

async function getCompanyInformationAlpha(symbol){
    let url = "https://www.alphavantage.co/query?function=OVERVIEW&symbol=" + symbol +"&apikey=" + alphaKey.getAlphaKey();
    try {
        let responce = await fetch(url);
        if ( responce.ok){
            const c = await responce.json();
            const  { Symbol,Name, Description,Exchange, Currency, Country, Sector, Industry, FullTimeEmployees, MarketCapitalization} = c;
            return { Symbol,Name, Description,Exchange, Currency, Country, Sector, Industry, FullTimeEmployees, MarketCapitalization} ;
        }               
    } catch (error) {
        console.error(error);
    }
    return {};
}


module.exports = {
    getCompanyInformation
}
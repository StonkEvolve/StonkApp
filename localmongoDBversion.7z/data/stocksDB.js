const { ObjectId } = require('mongodb');
const db = require("./db");

/*#region  Stocks */

function getStocksCollection() {
    return db.getCollection("stocks");
}

async function deleteAllStocks() {
    let collection = await getStocksCollection();
    return collection.deleteMany({});
}


async function loadStock(stock) {
    let collection = await getStocksCollection();
    await collection.insertOne(stock);
    return stock;
}

/*#endregion */

/*#region  Companies */
function getCompaniesCollection() {
    return db.getCollection("companies");
}

async function tryToFindCompanyInformation(symbolToFind) {
    try {
       let collection = await getCompaniesCollection();
       return collection.findOne({ Symbol:symbolToFind});
        
    }  catch ( err ) {
        console.error("err=", err)
        return null
    }   
}

async function saveCompanyInformation(company){
    let collection = await getCompaniesCollection();
    return  collection.insertOne(company);
}

/*#endregion */
module.exports = {
    getStocksCollection,
    deleteAllStocks,
    loadStock,

    tryToFindCompanyInformation,
    saveCompanyInformation
}
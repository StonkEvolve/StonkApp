require("../models/appSmall")
const clientDB = require("../data/client");

console.log("Start")
let client = {
    firstName: "Paul",
    lastName: "McCartney",
    birthdate:  new Date(1945, 11, 17),
    phoneNumber: "911",
    eMail: "paulMcCartmey@gmail.com",
  };
const id ='60a09d2c55195e467065c469';
 //clientDB.createClient(client).then(console.log("End"));
 clientDB.getClientById(id).then((c) => console.log(c.eMail));
 clientDB.getClientPasswordById(id).then((c) => console.log(c.password));
 clientDB.getClientList().then((c) => console.log(c));
 clientDB.deleteClient(id);
 //getClientPasswordById
 //clientDB.updateClient('60a09d2c55195e467065c469', {password:"1234"});


// Return Alpha vantage apikey 
function getAlphaKey() {
    return '3PRM4UE4KPUFCKVB';
}

module.exports = {
    getAlphaKey
}